/**
 * 
 */
package nvwofactory;

import java.util.Scanner;

/**
 * 项目名称：设计模式
 * 类名称：Client
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午11:37:16
 * @version
 */
public class Client {
	
	public static void main(String[] args) {
		try {

		String strOper=null;
		Scanner sc=new Scanner(System.in);
		
		for(;;)
		{
			System.out.println("你已经是女娲啦！输入（M）创造男人，（W）创造女人，（R）创造机器人！：");
			strOper=sc.next();
			
			if(strOper.equals("M")||strOper.equals("W")||strOper.equals("R"))
			{
				break;
			}
			else
			{
				System.out.println("输入错误！");
			}
			
		}
		
		sc.close();
		
		//初始化人类
		Person person=null;
		//初始化女娲类
		Nvwa nvwa=new Nvwa();
		//女娲类调用方法获得人类
		person = nvwa.GetPerson(strOper);
		//人类调用说话方法
		person.Say();
		
		
		} catch (Exception e) {
			System.out.println("程序错误："+e);
		}
	}

}

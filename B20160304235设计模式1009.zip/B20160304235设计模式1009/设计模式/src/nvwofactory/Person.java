/**
 * 
 */
package nvwofactory;

/**
 * 项目名称：设计模式
 * 类名称：Person
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午11:28:18
 * @version
 */
public abstract class Person {
	
	public abstract void Say();

}

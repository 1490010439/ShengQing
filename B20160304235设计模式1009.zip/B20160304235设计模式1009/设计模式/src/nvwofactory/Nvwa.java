/**
 * 
 */
package nvwofactory;

/**
 * 项目名称：设计模式
 * 类名称：Nvwa
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午11:31:23
 * @version
 */
public class Nvwa {
	
	public Person GetPerson(String strOper)
	{
		Person person=null;
		
		try {
			switch (strOper) {
			case "M":
				person=new Men();
				break;
			case "W":
				person=new Women();
				break;
			case "R":
				person=new Robot();
				break;
			default:
				break;
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}

		
		return person;
	}

}

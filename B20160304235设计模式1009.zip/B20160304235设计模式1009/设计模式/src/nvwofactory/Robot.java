/**
 * 
 */
package nvwofactory;

/**
 * 项目名称：设计模式
 * 类名称：Robot
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午11:29:09
 * @version
 */
public class Robot extends Person{

	/* 
	 * 创建人：钟盛勤
	 * 来自：@see nvwofactory.Person#Say()
	 */
	@Override
	public void Say() {
		System.out.println("我。。是。。机器人，biu biu ....！");
	}

}

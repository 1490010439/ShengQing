/**
 * 
 */
package factory;

import java.util.Scanner;

/**
 * 项目名称：设计模式
 * 类名称：Client
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午10:53:18
 * @version
 */
public class Client {
	
	public static void main(String[] args) {
		
		double numberA = 0;
		double numberB=0;
		double result=0;
		String strOper=null;
		Scanner sc=new Scanner(System.in);
		
		try {
			
			   System.out.println("请输入double类型的数字numberA:");
			   numberA=sc.nextDouble();
			   
			  
			   for(;;)
			   {
				   System.out.println("请输入字符类型的操作符(+，-，*，/)");
				   strOper=sc.next();
				   //只要输入的是正确的操作符就跳出循环，否则一直输入操作符
				   if(strOper.equals("+")||strOper.equals("-")||strOper.equals("*")||strOper.equals("/"))
				   {
					   break;
				   }
				   else
				   {
					   System.out.println("输入错误！");
				   }
			   }   
			
			   
			   System.out.println("请输入double类型的数字numberB:");
			   numberB=sc.nextDouble();
			
	
		
	 
	   
	   //关闭输入
	   sc.close();
	   
	   
	   //操作类
	   Operation Operation;
	   //工厂类
	   OperationFactory Operationfactory=new OperationFactory();
	   //工厂类根据操作符返回操作类
	   Operation=Operationfactory.GetOperation(strOper);
	   //操作类调用方法返回结果
	   result=Operation.GetResulet(numberA, numberB);
	   
	   //输出结果
	   System.out.println("\n--------------------------------------\n");
	   System.out.println(numberA+""+strOper+""+numberB+"="+result);
	   
	   
		} catch (Exception e) {
			System.out.println("程序错误！:"+e);
		}
		
	}

}

/**
 * 
 */
package factory;

/**
 * 项目名称：设计模式
 * 类名称：OperationDiv
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午10:41:57
 * @version
 */
public class OperationDiv extends Operation{

	/* 
	 * 创建人：钟盛勤
	 * 来自：@see factory.Operation#GetResulet(double, double)
	 */
	@Override
	public double GetResulet(double numberA, double numberB) {
		// TODO Auto-generated method stub
		
		if(numberB==0)
		{
			System.out.println("除数不能为0");
			return 0;
		}
		else
		{
			return numberA/numberB;
		}
		
		
	}

}

/**
 * 
 */
package factory;

/**
 * 项目名称：设计模式
 * 类名称：OperationFactory
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午10:44:38
 * @version
 */
public class OperationFactory {
	
	public  Operation GetOperation(String strOper)
	{
		Operation operation=null;
		
		try {
			switch (strOper) {
			case "+":
				operation=new OperationAdd();
				break;
			case "-":
				operation=new OperationSub();
				break;
			case "*":
				operation=new OperationMul();
				break;
			case "/":
				operation=new OperationDiv();
				break;
			default:
				break;
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}

		return operation;
	}

}

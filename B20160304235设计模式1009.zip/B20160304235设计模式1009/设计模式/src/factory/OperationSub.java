/**
 * 
 */
package factory;

/**
 * 项目名称：设计模式
 * 类名称：OperationSub
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午10:41:27
 * @version
 */
public class OperationSub extends Operation{

	/* 
	 * 创建人：钟盛勤
	 * 来自：@see factory.Operation#GetResulet(double, double)
	 */
	@Override
	public double GetResulet(double numberA, double numberB) {
		// TODO Auto-generated method stub
		return numberA-numberB;
	}

}

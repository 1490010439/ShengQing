/**
 * 
 */
package factory;

/**
 * 项目名称：设计模式
 * 类名称：Operation
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午10:40:01
 * @version
 */
public abstract class Operation {
	
	public abstract double GetResulet( double numberA ,double numberB);

}

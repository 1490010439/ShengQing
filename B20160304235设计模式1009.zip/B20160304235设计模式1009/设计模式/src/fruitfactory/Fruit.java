/**
 * 
 */
package fruitfactory;

/**
 * 项目名称：设计模式
 * 类名称：Fruit
 * 创建人：钟盛勤
 * 创建时间：2018-10-9上午11:55:16
 * @version
 */
public abstract class Fruit {
	
	public abstract void Grow();
	
	public abstract void Harvest();
	
	public abstract void Plant();

}

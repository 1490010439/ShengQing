/**
 * 
 */
package fruitfactory;

/**
 * 项目名称：设计模式
 * 类名称：Apple
 * 创建人：钟盛勤
 * 创建时间：2018-10-9下午12:05:06
 * @version
 */
public class Apple extends Fruit{

	/* 
	 * 创建人：钟盛勤
	 * 来自：@see fruitfactory.Fruit#Grow()
	 */
	@Override
	public void Grow() {
		System.out.println("我是苹果，我正在成长！");
	}

	/* 
	 * 创建人：钟盛勤
	 * 来自：@see fruitfactory.Fruit#Harvest()
	 */
	@Override
	public void Harvest() {
		System.out.println("我是苹果，我正在被收获！");
		
	}

	/* 
	 * 创建人：钟盛勤
	 * 来自：@see fruitfactory.Fruit#Plant()
	 */
	@Override
	public void Plant() {
		System.out.println("我是苹果，我正在被种植！");
		
	}

}

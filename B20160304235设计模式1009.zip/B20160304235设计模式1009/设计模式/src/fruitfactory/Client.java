/**
 * 
 */
package fruitfactory;

import java.util.Scanner;

/**
 * 项目名称：设计模式
 * 类名称：Client
 * 创建人：钟盛勤
 * 创建时间：2018-10-9下午12:13:47
 * @version
 */
public class Client {
	
	public static void main(String[] args) {
		
		
		String fruitName=null;
		Scanner sc=new Scanner(System.in);
		
		try {
			
			for(;;)
			{
				System.out.println("欢迎来到开心农场，请输入水果名,苹果（Apple），香蕉（Banana），橘子（Orange）：");
				fruitName=sc.nextLine();
				if(fruitName.equals("Apple")||fruitName.equals("Banana")||fruitName.equals("Orange"))
				{
					break;
				}
				else
				{
					System.out.println("输入错误！");
				}
				
			}
			
		sc.close();
		
		//初始化水果类
		Fruit fruit=null;
		//初始化农场类
		Fram fram=new Fram();
		//农场类根据水果名字得到水果类
		fruit=fram.GetFruit(fruitName);
		//水果类调用种植，成长，收获方法！
		fruit.Plant();
		fruit.Grow();
		fruit.Harvest();
			
		} catch (Exception e) {
			System.out.println("程序错误"+e);
		}
		
		
	}

}

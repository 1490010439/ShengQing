/**
 * 
 */
package fruitfactory;

/**
 * 项目名称：设计模式
 * 类名称：Fram
 * 创建人：钟盛勤
 * 创建时间：2018-10-9下午12:10:17
 * @version
 */
public class Fram {
	
	public Fruit GetFruit( String fruitName )
	{
		Fruit fruit=null;
		
		try {
			
			switch (fruitName) {
			case "Apple":
				fruit=new Apple();
				break;
			case "Banana":
				fruit=new Banana();
				break;
			case "Orange":
				fruit=new Orange();
				break;

			default:
				break;
			}
			
			
		} catch (Exception e) {
			System.out.println("错误:"+e);
		}
		
		return fruit;
	}

}

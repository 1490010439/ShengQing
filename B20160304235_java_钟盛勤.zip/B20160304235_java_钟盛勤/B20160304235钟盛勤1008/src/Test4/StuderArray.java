package Test4;

public class StuderArray {
	
	String[] initArray()
	{
		String[] data1 = {"����","����","����","����"};
		return data1;
	}

	String[][] initArray2()
	{
		String[][] data2={
				{"1","2","3","4"},
				{"5","6","7","8"},
				{"9","10","11","12"},
				{"13","14","15","16"},
	
		};
		
		return data2;
	}
	
	
}

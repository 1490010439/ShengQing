package Test4;

import java.util.Scanner;

public class Mystring {
	
	public static void main(String[] args) {
		
		String a;
		String c;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("�������ַ�����\n");
		a=sc.next();
		System.out.println("������Ҫɾ�����ַ���\n");
		c=sc.next();
		
		System.out.println("ɾ����"+deleteSubString(a,c));
		
	}


	public static String deleteSubString(String str1,String str2)
	{
		StringBuffer sb=new StringBuffer(str1);
		int delCont=0;
		String obj = null;
		
		while(true)
		{
			int index = sb.indexOf(str2);
			if(index== -1)
			{
				break;
			}
			sb.delete(index, index+str2.length());
			delCont++;
		}
		if(delCont!=0)
		{
			obj=sb.toString();
			
		}
		else
		{
			obj="0";
			
		}
			
		
		
		return obj;
	}
	
	
}



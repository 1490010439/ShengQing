package Test4;

import Test2.User;

public class UserManager {
	private int size = 100;
	
	private User[] userList = new User[size];
	private int index;
	
	
	public boolean addUser(User user)
	{
		if(index<size)
		{
			userList[index]=user;
			index++;
			return true;
		}else
		{
			return false;
		}
	}
	
	public User getUserByName(String name)
	{
		for(int i=0;i<index;i++)
		{
		  User user=userList[i];
		  if(name.equals(user.name))
		  {
			  return user;
		  }
		}
		return null;
	}
	
	public boolean exist(String name,String pwd)
	{
		for(int i=0;i<index;i++)
		{
		  User user=userList[i];
		  if(name.equals(user.name)&&pwd.equals(user.pwd))
		  {
			  return true;
		  }
		}
		return false;
		
	}

}

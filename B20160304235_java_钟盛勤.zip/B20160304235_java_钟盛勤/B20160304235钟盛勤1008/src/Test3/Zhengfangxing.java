package Test3;

public class Zhengfangxing implements Juxing{

	public double mianji(double chang, double kuang) {
		
		return 	chang*kuang;
	}

	public double zouchang(double chang, double kuang) {

		return (chang+kuang)*2;
	}

}

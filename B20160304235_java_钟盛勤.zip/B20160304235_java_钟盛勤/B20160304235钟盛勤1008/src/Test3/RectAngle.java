package Test3;

public class RectAngle implements Printable,Juxing{

	double chang;
	double kuang;
	
	public RectAngle()
	{
		
	}
	
	public RectAngle(double chang,double kuang)
	{
		this.chang=chang;
		this.kuang=kuang;
	}
	
    public double mianji(double chang, double kuang) {
		
		return 	chang*kuang;
	}

	public double zouchang(double chang, double kuang) {

		return (chang+kuang)*2;
	}
	
	public void printWay() {
		
		System.out.println("�߳���"+chang+"�߿���"+kuang+
				"�����"+mianji(chang,kuang)+"�ܳ�:"+zouchang(chang,kuang));
		
	}

	public void printcharWay(char a) {
		
		for(int i=0;i<kuang;i++)
		{
			for(int j=0;j<chang;j++)
			{
				System.out.print(a);
			}
			
			System.out.println("\n");
		}
		
	}

}

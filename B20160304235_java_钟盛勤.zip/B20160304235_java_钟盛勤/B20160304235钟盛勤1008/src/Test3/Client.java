package Test3;

public class Client {

	public static void main(String[] args) {
		
		Zhengfangxing zf=new Zhengfangxing();
		System.out.println(zf.mianji(2, 2)+"||"+zf.zouchang(2, 2));
		
		RectAngle rc=new RectAngle(2,3);
		rc.printWay();
		rc.printcharWay('*');
		
		
	}
}

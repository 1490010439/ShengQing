package Test3;

public interface Juxing {
	
	double mianji(double chang,double kuang);
	double zouchang(double chang,double kuang);

}

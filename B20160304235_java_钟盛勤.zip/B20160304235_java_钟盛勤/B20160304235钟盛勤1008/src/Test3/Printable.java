package Test3;

public interface Printable {
	
	public void printWay();
	public void printcharWay(char a);

}

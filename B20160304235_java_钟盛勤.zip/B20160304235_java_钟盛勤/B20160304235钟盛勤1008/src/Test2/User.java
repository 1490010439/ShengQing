package Test2;


import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class User {
	
	public String name;
	public String pwd;
	public int age;
	public int born;
	
	
	private int setAge()
	{
	    Date mydate;
		GregorianCalendar cal=new GregorianCalendar();
		mydate=cal.getTime();
	
		int myyear;
		myyear=cal.get(Calendar.YEAR);
		
		System.out.println(cal.get(Calendar.MONTH));
		
		System.out.println("现在的时间："+mydate.toString());
		return myyear-born;
	}
	
	public User(String name,String pwd)
	{
		this.name=name;
		this.pwd=pwd;
	}
	
	public User(String name,String pwd,int born)
	{
		this.name=name;
		this.pwd=pwd;
		this.born=born;
		this.age=setAge();
	}
	
	public void  show()
	{
		
		System.out.println("姓名:"+name+",密码:"+pwd+",出生年份:"+born+",年龄:"+age);
	}
	
	
	public static void main(String[] args) {
		User user=new User("钟盛勤","5201314",1997);
		user.show();
		
	}

}

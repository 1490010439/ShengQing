/**
 * 
 */
package Test2;


/**
 * 项目名称：B20160304235钟盛勤1008
 * 类名称：client
 * 创建人：钟盛勤
 * 创建时间：2018-10-8下午4:29:15
 * @version
 */
public class client {
	
	public static void main(String[] args) {
		
		try {
			
	           Timeutil timeutil=new Timeutil();
	           System.out.println("现在的时间："+timeutil.getNowTime());
	           System.out.println("现在的时间_年："+timeutil.getNowYear());
	           System.out.println("现在的时间_月："+timeutil.getNowMONTH());
	           System.out.println("现在的时间_日："+timeutil.getNowDay());
	           System.out.println("现在的时间_时："+timeutil.getNowHours());
	           System.out.println("现在的时间_分："+timeutil.getNowMinutes());
	           System.out.println("现在的时间_秒："+timeutil.getNowSeconds());
	           
	           String strDate = "1997-05-28";
	           String resule=timeutil.getBiJiaoDateString(strDate);
	           System.out.println(resule);
		
			
		} catch (Exception e) {
			System.out.println(e);
		}
	
			
			
			
		
	}

}

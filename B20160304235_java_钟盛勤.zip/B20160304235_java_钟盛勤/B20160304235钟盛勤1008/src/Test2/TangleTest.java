package Test2;

public class TangleTest {
	
	public static void main(String[] args) {
		Tangle tr=new Tangle();
		tr.confirm(5, 5, 5);
	}

}

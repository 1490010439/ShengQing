package Test2;

import java.util.Scanner;

public class Tangle {
	
	public static void confirm(float a,float b,float c)
	{
		if((a+b>c)&&(a+c>b)&&(b+c>a))
		{
			System.out.println("能构成三角形");
		}
		else
		{
			System.out.println("不能构成三角形");
		}
	}
	
	public static void main(String[] args){

		try {
			
			float a,b,c;
			Scanner s=new Scanner(System.in);
			System.out.println("请输入三角形边长a:\n");
			a=s.nextFloat();
			System.out.println("请输入三角形边长b:\n");
			b=s.nextFloat();
			System.out.println("请输入三角形边长c:\n");
			c=s.nextFloat();
			s.close();
			confirm(a,b,c);
			
		} catch (Exception e) {
			System.out.println("错误："+e);
		}
		
		
	}

}

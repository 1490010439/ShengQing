/**
 * 
 */
package Test2;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * 项目名称：B20160304235钟盛勤1008
 * 类名称：Timeutil 时间工具类
 * 创建人：钟盛勤
 * 创建时间：2018-10-8下午4:23:27
 * @version
 */
public class Timeutil {
	
	
	public static GregorianCalendar cal;
	public Date date;
	
	//现在的时间
	private Date NowTime;
	//现在年份
	private int NowYear;
	//现在月份
	private int NowMONTH;
	//现在日
	private int NowDay;
	//现在时
	private int NowHours;
	//现在分
	private int NowMinutes;
	//现在秒
	private int NowSeconds;
	
	//初始化
	public Timeutil(){
		cal=new GregorianCalendar();
		//将该对象的时间设置为当前时间
		cal.setTime(new Date());
		date=new Date();
	}
	
	
	/**
	 * 项目名称：B20160304235钟盛勤1008
	 * 方法名称：该方法输入  日期的format
	 * 创建人：钟盛勤
	 * 创建时间：2018-10-8下午4:23:27
	 * @version
	 * yyyy：年
	 * MM：月dd：日
	 * hh：1~12小时制(1-12)
	 * HH：24小时制(0-23)
	 * mm：分
	 * ss：秒
	 * S：毫秒
	 * E：星期几
	 * D：一年中的第几天
	 * F：一月中的第几个星期(会把这个月总共过的天数除以7)
	 * w：一年中的第几个星期
	 * W：一月中的第几星期(会根据实际情况来算)
	 * a：上下午标识
	 * k：和HH差不多，表示一天24小时制(1-24)。
	 * K：和hh差不多，表示一天12小时制(0-11)。
	 * z：表示时区
	 */
	public String getdateString(String dataformat)
	{
		 SimpleDateFormat format = new SimpleDateFormat(dataformat);
         Calendar c = Calendar.getInstance();
         c.setTime(date);
         Date d = c.getTime();
         String dataString =format.format(d);
         return dataString;
	}
	
	public String getdateString(String dataformat,Date mydate)
	{
		 SimpleDateFormat format = new SimpleDateFormat(dataformat);
         Calendar c = Calendar.getInstance();
         c.setTime(mydate);
         Date d = c.getTime();
         String dataString =format.format(d);
         return dataString;
	}
	
	
	
	public String getBiJiaoDateString(String strDate)
	{
		Date bijiaodate=null;
		try {
	     SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
          bijiaodate=simpleDateFormat.parse(strDate);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e);
		}
		
		String dataString=null;
		int mynowYear=getNowYear();
		int mynowMONTH=getNowMONTH();
		int mynowDay=getNowDay();
		
		//把要比较的年月日分离出来
		int bijiaoYear=Integer.parseInt(getdateString("YYYY",bijiaodate));
		int bijiaoMONTH=Integer.parseInt(getdateString("MM",bijiaodate));
		
		 String day=getdateString("dd",bijiaodate);

         //如果日期小于10就把前面的0截取掉
         if(day.compareTo("10")<0)
         {
        	 day=day.substring(1);
         }

         int bijiaoDay = Integer.parseInt(day);
         
         System.out.println("当前的年月日："+mynowYear+","+mynowMONTH+","+mynowDay);
         System.out.println("要比较的年月日："+bijiaoYear+","+bijiaoMONTH+","+bijiaoDay);
         
         int resultYear=mynowYear-bijiaoYear;
         int resultMONTH=myabs( mynowMONTH-bijiaoMONTH );
         int resultDay=myabs( mynowDay-bijiaoDay );
         
         if(mynowMONTH-bijiaoMONTH<0)
         {
        	 resultYear--;
         }
         
         if(mynowDay-bijiaoDay<0)
         {
        	 resultMONTH--;
         }
		
         
         dataString="相差了"+resultYear+"年,"+resultMONTH+"月,"+resultDay+"天";
		
		return dataString;
		
	}
	
	public int myabs(int a)
	{
		return (a<0)? -a : a;
	}
	
	
	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the cal
	 */
	public GregorianCalendar getCal() {
		return cal;
	}
	/**
	 * @param cal the cal to set
	 */
	public void setCal(GregorianCalendar cal) {
		this.cal = cal;
	}
	/**
	 * @return the nowTime
	 */
	public Date getNowTime() {
		
		
		NowTime=cal.getTime();
		
		return NowTime;
	}
	/**
	 * @param nowTime the nowTime to set
	 */
	public void setNowTime(Date nowTime) {
		NowTime = nowTime;
	}
	/**
	 * @return the nowYear
	 */
	public int getNowYear() {

		NowYear=cal.get(GregorianCalendar.YEAR);
		return NowYear;
	}
	/**
	 * @param nowYear the nowYear to set
	 */
	public void setNowYear(int nowYear) {
		NowYear = nowYear;
	}
	/**
	 * @return the nowMONTH
	 */
	public int getNowMONTH() {
		
           
           NowMONTH = Integer.parseInt(getdateString("MM"));
		
		return NowMONTH;
	}
	/**
	 * @param nowMONTH the nowMONTH to set
	 */
	public void setNowMONTH(int nowMONTH) {
		NowMONTH = nowMONTH;
	}
	

	/**
	 * @return the nowDay
	 */
	public int getNowDay() {
		
		

         String day=getdateString("dd");

         //如果日期小于10就把前面的0截取掉
         if(day.compareTo("10")<0)
         {
        	 day=day.substring(1);
         }

         NowDay = Integer.parseInt(day);
		
		return NowDay;
	}



	/**
	 * @param nowDay the nowDay to set
	 */
	public void setNowDay(int nowDay) {
		NowDay = nowDay;
	}



	/**
	 * @return the nowHours
	 */
	public int getNowHours() {
		NowHours=cal.getTime().getHours();
		return NowHours;
	}
	/**
	 * @param nowHours the nowHours to set
	 */
	public void setNowHours(int nowHours) {
		
		NowHours = nowHours;
	}
	/**
	 * @return the nowMinutes
	 */
	public int getNowMinutes() {
		
		NowMinutes=cal.getTime().getMinutes();
		return NowMinutes;
	}
	/**
	 * @param nowMinutes the nowMinutes to set
	 */
	public void setNowMinutes(int nowMinutes) {
		
		NowMinutes = nowMinutes;
	}
	/**
	 * @return the nowSeconds
	 */
	public int getNowSeconds() {
		
		NowSeconds=cal.getTime().getSeconds();
		return NowSeconds;
	}
	/**
	 * @param nowSeconds the nowSeconds to set
	 */
	public void setNowSeconds(int nowSeconds) {
		NowSeconds = nowSeconds;
	}
		

}

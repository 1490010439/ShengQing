package com.tz.main;

public class Test {
	
	public static void main(String[] args) {
		
		int a=3,b=-5;
		boolean f=true;
		System.out.println("--a % b ++��ֵ��:"+(--a % b ++));
		System.out.println("a>=1&&a<=12?a:b��ֵ��:"+(a>=1&&a<=12?a:b));

	}

}

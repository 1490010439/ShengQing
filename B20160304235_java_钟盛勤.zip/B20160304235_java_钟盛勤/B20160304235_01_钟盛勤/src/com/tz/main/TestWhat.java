package com.tz.main;

public class TestWhat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean leap; int year=2005;
		if((year%4==0 && year%100!=0)||(year%400==0))
			System.out.println(year+"is leap year");
		else
			System.out.println(year+"is not leap year");
		
		year=2016;
		
		if(year%4!=0)
			leap=false;
		else if(year%100!=0)
			leap=true;
		else if(year%400!=0)
			leap=false;
		else
			leap=true;
		
		if(leap==true)
			System.out.println(year+"is leap year");
		else
			System.out.println(year+"is not leap year");
		
		year=2050;
		if(year%4==0)
		{
			if(year%100==0)
			{
				if(year%400==0)
					leap=true;
				else
					leap=false;
			}
			else
				leap=false;
		}
		else
			leap=false;
		if(leap==true)
			System.out.println(year+"is leap year");
		else
			System.out.println(year+"is not leap year");
			
	}

}
